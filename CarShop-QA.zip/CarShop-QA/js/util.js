/**
 * Created by Mohammad Khomeiri
 * Date 4/7/2016.
 * program: util.js
 */

function doValidate_frmAddCar() {
    var form = $("#frmAddCar");

    form.validate({
        rules:{
            txtSellerName:{
                required: true
            },
            txtAddress:{
                required: true
            },
            txtCity:{
                required: true
            },
            txtPhone:{
                required: true,
                phoneCheck: true
            },
            txtEmailAddress:{
                required: true,
                email: true
            },
            txtCarMake:{
                required: true
            },
            txtCarModel:{
                required: true
            },
            txtCarYear:{
                required: true,
                minlength: [4]
            }
        },
        messages:{
            txtSellerName:{
                required: "Please insert the seller name"
            },
            txtAddress:{
                required: "Please insert your address"
            },
            txtCity:{
                required: "Please insert your city"
            },
            txtPhone:{
                required: "Please insert your phone number",
                phoneCheck: "Please insert valid phone number"
            },
            txtEmailAddress:{
                required: "Please insert your email address",
                email: "Please insert valid email address"
            },
            txtCarMake:{
                required: "Please insert the vehicle make"
            },
            txtCarModel:{
                required: "Please insert the vehicle model"
            },
            txtCarYear:{
                required: "Please insert the vehicle year",
                minlength: "Please inset valid"
            }
        }
    });
    return form.valid();
}

jQuery.validator.addMethod("phoneCheck", function(value, element) {
    var regex = /^\(?([0-9]{3})\)?[-. ]?([0-9]{3})[-. ]?([0-9]{4})$/;
    return this.optional(element) | regex.test(value);
});