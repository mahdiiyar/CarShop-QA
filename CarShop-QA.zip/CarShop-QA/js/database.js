/**
 * Created by Mohammad Khomeiri
 * Date 4/7/2016.
 * program: database.js
 */

function getCarInfo(){

    var input = localStorage.getItem(String(localStorage.length));
    var split = input.split('/');
    document.getElementById("lblSellerName").innerHTML = split[0];
    document.getElementById("lblAddress").innerHTML = split[1];
    document.getElementById("lblCity").innerHTML = split[2];
    document.getElementById("lblPhone").innerHTML = split[3];
    document.getElementById("lblEmailAddress").innerHTML = split[4];
    document.getElementById("lblCarMake").innerHTML = split[5];
    document.getElementById("lblCarModel").innerHTML = split[6];
    document.getElementById("lblCarYear").innerHTML = split[7];
    document.getElementById("displayLink").innerHTML="http://www.jdpower.com/cars/search/"+split[7]+"-"+
        split[5]+"-"+split[6]+"/"+split[5]+"/"+split[6]+"/non-awardees-included/any-rating/"+split[7]+"//all-msrp-ranges/all-mpg-ranges/";
    document.getElementById("displayLink").href="http://www.jdpower.com/cars/search/"+split[7]+
        "-"+split[5]+"-"+split[6]+"/"+split[5]+"/"+split[6]+"/non-awardees-included/any-rating/"+split[7]+"//all-msrp-ranges/all-mpg-ranges/";
}

function searchCarByMake() {
    var searchCars = [];
    for (var i = 1; i <= localStorage.length; i++) {
        var getInputs = localStorage.getItem(i);
        var split = getInputs.split('/');
        searchCars.push(split);
    }
    var searchByMake = document.getElementById("txtSearchByMake").value;

    var results = [];
    for (i = 0; i < searchCars.length; i++) {
        if (searchCars[i][5] == searchByMake) {
            results.push(searchCars[i]);
        }

    }
    DisplaySaved(results);
    return false;

}

function searchCarByModel() {
    var searchCars = [];
    for (var i = 1; i <= localStorage.length; i++) {
        var getInputs = localStorage.getItem(i);
        var split = getInputs.split('/');
        searchCars.push(split);
    }
    var searchByModel = document.getElementById("txtSearchByModel").value;

    var results = [];
    for (i = 0; i < searchCars.length; i++) {
        if (searchCars[i][6] == searchByModel) {
            results.push(searchCars[i]);
        }

    }
    DisplaySaved(results);
    return false;

}

function DisplaySaved(searchCars) {
    var HTML = "";
    for (var i = 0; i < searchCars.length; i++) {
        HTML += "<tr>";
        for (var j = 0; j < searchCars[i].length; j++) {
            HTML += "<td>" + searchCars[i][j] + " " + " || " +"</td>";
            HTML += " ";

        }
        HTML += "</tr>";
    }
    HTML += "</table>";
    document.getElementById("records").innerHTML = HTML;
}