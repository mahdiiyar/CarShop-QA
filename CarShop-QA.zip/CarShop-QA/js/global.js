/**
 * Created by Mohammad Khomeiri
 * Date 4/7/2016.
 * program: global.js
 */

function btnAddCar_click() {
    if (doValidate_frmAddCar()) {
        var sellerName = $("#txtSellerName").val();
        var address =$("#txtAddress").val();
        var city= $("#txtCity").val();
        var phone=$("#txtPhone").val();
        var emailAddress=$("#txtEmailAddress").val();
        var carMake= $("#txtCarMake").val();
        var carModel=$("#txtCarModel").val();
        var carYear=$("#txtCarYear").val();

        var key = localStorage.length + 1;
        var value = sellerName + "/" + address + "/" + city + "/" + phone +
            "/" + emailAddress + "/" + carMake + "/" + carModel + "/" + carYear;
        localStorage.setItem(String(key), value);
        return true;
    }
    else {
        return false;
    }
}

function displayCar_page(){
    getCarInfo();
}

function btnSearchByMake_click(){
    searchCarByMake();
}

function btnSearchByModel_click(){
    searchCarByModel();
}

function init() {
    $("#btnAddCar").on("click", btnAddCar_click);
    $("#btnSearchByMake").on("click", btnSearchByMake_click);
    $("#btnSearchByModel").on("click", btnSearchByModel_click);
    $("#displayCar").on("pageshow", displayCar_page);
}


$(document).ready(function () {
   init();
});
